import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'input-user-data-form',
  templateUrl: './input-user-data-form.component.html',
  styleUrls: ['./input-user-data-form.component.scss']
})
export class InputUserDataFormComponent implements OnInit {
  registered = false;
  submitted = false;
  userForm: FormGroup;
  guid: string;

  constructor(
    private formBuider: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) { }

  ngOnInit() {
    this.userForm = this.formBuider.group({
      firstName: ['', [Validators.required, Validators.maxLength(50)] ],
      lastName: ['', [Validators.required, Validators.maxLength(50)] ],
      email: ['', [Validators.required, Validators.email, Validators.maxLength(50)] ],
      zipcode: ['', [Validators.required, Validators.pattern('^[0-9]{5}(?:-[0-9]{4})?$')] ],
      password: ['', [Validators.required, Validators.minLength(5), Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')]],
    });

    this.http.get('http://localhost:3000/api/v1/generate_uid').subscribe(
      (data: any) => {
        console.log('Guid: (sucess)', data);

        this.guid = data.guid;
      },
      err => console.log('There was an error generating the proper GUID on the server', err)
    );
  }

  invalidFirstName() {
    return (this.submitted && this.userForm.controls.firstName.errors != null);
  }

  invalidLastName() {
    return (this.submitted && this.userForm.controls.lastName.errors != null);
  }

  invalidEmail() {
    return (this.submitted && this.userForm.controls.email.errors != null);
  }

  invalidZipCode() {
    return (this.submitted && this.userForm.controls.zipcode.errors != null);
  }

  invalidPassword() {
    return (this.submitted && this.userForm.controls.password.errors != null);
  }

  onSubmit() {
    this.submitted = true;

    if (this.userForm.invalid) {
      return;
    }

    const data = { guid: this.guid, ...this.userForm.value };

    this.http.post('http://localhost:3000/api/v1/customer', data).subscribe(
      (res: any) => {
        console.log('Submited: (sucess)', res);

        this.router.navigate([ '/user/', res.customer.uid]);
      },
      err => {
        console.log('Error: ', err);
      }
    );

    this.registered = true;
  }

}

import { Component, OnInit } from '@angular/core';
import { UserInfoModel } from 'src/app/model/UserInfoModel';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'display-user-data',
  templateUrl: './display-user-data.component.html',
  styleUrls: ['./display-user-data.component.scss']
})
export class DisplayUserDataComponent implements OnInit {
  private subscriber: any;

  user: UserInfoModel = new UserInfoModel(
    {
      guid: 'D21ds12x',
      uid: 'cust2dsa12dsa',
      firstName: 'John',
      lastName: 'Doe',
      email: 'email@email.com',
      zipcode: 10283,
      password: 'Idasn2x2#'
    }
  );

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.subscriber = this.route.params.subscribe(
      params => {
        console.log('Route params:', params);

        this.http.get(`http://localhost:3000/api/v1/customer/${params.uid}`).subscribe(
          (data: any) => {
            console.log('Display: (sucess)', data);

            this.user = new UserInfoModel(data.customer);
          }
        );
      }
    );

  }

}
